﻿namespace PokerGame.Enums;

public enum Suit
{
    Club,
    Diamond,
    Heart,
    Spade
}